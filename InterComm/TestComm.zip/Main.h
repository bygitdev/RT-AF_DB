//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <System.Win.ScktComp.hpp>
//---------------------------------------------------------------------------

#include "PACKET.h"


class TFrmMain : public TForm
{
__published:	// IDE-managed Components
	TMemo *MemoLog;
	TButton *Button1;
	TClientSocket *ClientSocket;
	TLabel *Label1;
	TEdit *EditHost;
	TLabel *Label2;
	TEdit *EditPort;
	TButton *Button4;
	TButton *Button2;
	TButton *Button3;
	TEdit *EditSendData;
	TMemo *MemoServer;
	TServerSocket *ServerSocket;
	TButton *Button5;
	TEdit *EditComm1;
	TLabel *Label3;
	TLabel *Label4;
	TEdit *EditComm4;
	TEdit *EditComm5;
	TEdit *EditComm2;
	TLabel *Label5;
	TLabel *Label6;
	TEdit *EditComm3;
	TLabel *Label7;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall ClientSocketConnect(TObject *Sender, TCustomWinSocket *Socket);
	void __fastcall ClientSocketDisconnect(TObject *Sender, TCustomWinSocket *Socket);
	void __fastcall ClientSocketError(TObject *Sender, TCustomWinSocket *Socket, TErrorEvent ErrorEvent,
          int &ErrorCode);
	void __fastcall ClientSocketRead(TObject *Sender, TCustomWinSocket *Socket);
	void __fastcall Button4Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button5Click(TObject *Sender);
	void __fastcall ServerSocketClientRead(TObject *Sender, TCustomWinSocket *Socket);
	void __fastcall ServerSocketClientConnect(TObject *Sender, TCustomWinSocket *Socket);






private:	// User declarations
	TCustomWinSocket *m_Socket;
    TCustomWinSocket *m_ServerSocket;


    String  StrRecvBuffer;
    void __fastcall CommHistoryData(String StrTemp);
    void __fastcall CommReceiveData(String StrTemp);
    bool __fastcall m_SendPacketProcess();

public:		// User declarations
	__fastcall TFrmMain(TComponent* Owner);

};
//---------------------------------------------------------------------------
extern PACKAGE TFrmMain *FrmMain;
//---------------------------------------------------------------------------
#endif
