#ifndef _PACKET_H_
#define _PACKET_H_

/*
---------------------------
header		|	body ................
 4 bytes	|	n bytes ..........
---------------------------
*/

#pragma pack(push, 4)

typedef struct _tagMsgBody
{
    char 	cLotid[100];
    char 	cPCBid[100];
    int 	nIndexno;
    int 	nJobno;
    char  cJobname[200];
    char  cMapInfo[100];

}MSG_BODY;

typedef struct _tagMsgData
{
	int		bytes;	// sizeof MSG_DATA
    union
    {
    	MSG_BODY body;
        char reserved[1024];
    };
}MSG_DATA;

#pragma pack(pop)




#endif
