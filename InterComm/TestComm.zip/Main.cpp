//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Main.h"
#include "PACKET.h"
#include <stdio.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmMain *FrmMain;



//---------------------------------------------------------------------------
__fastcall TFrmMain::TFrmMain(TComponent* Owner)
	: TForm(Owner)
{

}
//---------------------------------------------------------------------------
void __fastcall TFrmMain::CommHistoryData(String StrTemp)
{

	MemoLog->Lines->Add(DateTimeToStr(Now()) + " : MESSAGE : " + StrTemp);
	MemoLog->Refresh();

	if(MemoLog->Lines->Count >1000)
	{

		TDateTime dt = Now();
		String FolderName = dt.FormatString("yyyy-mm-dd");
		String FileName = dt.FormatString("yyyy-mm-dd hh-nn-ss");
		String FullPath  =  "C:\\History\\CommHistory\\"+ FolderName +"\\";
		ForceDirectories(FullPath);

		MemoLog->Lines->SaveToFile(FullPath + FileName+".txt");

		MemoLog->Clear();
	}
}
//---------------------------------------------------------------------------
void __fastcall TFrmMain::CommReceiveData(String StrTemp)
{

	MemoServer->Lines->Add(DateTimeToStr(Now()) + " : MESSAGE : " + StrTemp);
	MemoServer->Refresh();

	if(MemoServer->Lines->Count >1000)
	{

		TDateTime dt = Now();
		String FolderName = dt.FormatString("yyyy-mm-dd");
		String FileName = dt.FormatString("yyyy-mm-dd hh-nn-ss");
		String FullPath  =  "C:\\History\\ServerHistory\\"+ FolderName +"\\";
		ForceDirectories(FullPath);

		MemoServer->Lines->SaveToFile(FullPath + FileName+".txt");

		MemoServer->Clear();
	}
}
//---------------------------------------------------------------------------
void __fastcall TFrmMain::Button1Click(TObject *Sender)
{
	if(ClientSocket->Active == true)
    {
    	ClientSocket->Active = false;
        CommHistoryData("Socket Active false");
    }
    else
    {
        if( EditHost->Text.Length()>0 && EditPort->Text.Length()>0 )
        {
//            ClientSocket->Host = EditHost->Text;
//            ClientSocket->Port = EditPort->Text.ToInt();

            ClientSocket->Active = true;
            CommHistoryData("Socket Active true");
        }
		else
        {
			CommHistoryData("Check the Socket Address!");
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmMain::ClientSocketConnect(TObject *Sender, TCustomWinSocket *Socket)

{
	CommHistoryData("Connect HOST :" + Socket->RemoteHost);
    CommHistoryData("Connect HOST :" + IntToStr(Socket->RemotePort));
    m_Socket =  Socket;
}
//---------------------------------------------------------------------------

void __fastcall TFrmMain::ClientSocketDisconnect(TObject *Sender, TCustomWinSocket *Socket)

{
	CommHistoryData("DISCONNECT SOCKET");
    m_Socket = NULL;
}
//---------------------------------------------------------------------------

void __fastcall TFrmMain::ClientSocketError(TObject *Sender, TCustomWinSocket *Socket,
          TErrorEvent ErrorEvent, int &ErrorCode)
{
	CommHistoryData("SOCKET ERROR");
     m_Socket = NULL;
}
//---------------------------------------------------------------------------

void __fastcall TFrmMain::ClientSocketRead(TObject *Sender, TCustomWinSocket *Socket)

{
    char *buf;
    int len = Socket->ReceiveLength();
    buf = new char[len];
    Socket->ReceiveBuf( buf, len );
    CommHistoryData( buf );
    delete [] buf;
}
//---------------------------------------------------------------------------

void __fastcall TFrmMain::Button4Click(TObject *Sender)
{
	MemoLog->Clear();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMain::Button3Click(TObject *Sender)
{
    try
    {
        ClientSocket->Socket->SendBuf(EditSendData->Text.c_str() , EditSendData->Text.Length());
    }
    catch(...)
    {
        CommHistoryData("SendData Exception Error");
    }
}
//---------------------------------------------------------------------------

bool __fastcall TFrmMain::m_SendPacketProcess()
{
	MSG_DATA data={0, };
	data.bytes = sizeof(data);

    strcpy(data.body.cLotid ,"TEST_LOTID");
    strcpy(data.body.cPCBid ,"TEST_PCBID");
    data.body.nIndexno    = 1;
    data.body.nJobno    = 5;
    strcpy(data.body.cJobname ,"JOBNAME_NO5");
    strcpy(data.body.cMapInfo ,"101010101010101010101010");

	try
	{
        m_Socket->SendBuf( &data , sizeof(data) );
        return true;
    }
	catch(Exception &e)
	{
		m_Socket = NULL;
		ShowMessage(e.Message);
        return false;
	}

}
//---------------------------------------------------------------------------

void __fastcall TFrmMain::Button2Click(TObject *Sender)
{
	m_SendPacketProcess();
}
//---------------------------------------------------------------------------

void __fastcall TFrmMain::Button5Click(TObject *Sender)
{
	if(ServerSocket->Active == true)
    {
    	ServerSocket->Active = false;
        CommReceiveData("Socket Active false");
    }
    else
    {
        if( EditHost->Text.Length()>0 && EditPort->Text.Length()>0 )
        {
            ServerSocket->Active = true;
            CommReceiveData("Socket Active true");
        }
		else
        {
			CommReceiveData("Check the SERVER Socket Address!");
        }
    }
}
//---------------------------------------------------------------------------


void __fastcall TFrmMain::ServerSocketClientRead(TObject *Sender, TCustomWinSocket *Socket)

{
	MSG_DATA data={0, };

    char *buf = NULL;
	try
	{
    	while(1)
        {
            int bytes = Socket->ReceiveBuf(&data.bytes, 4);

            if (bytes != 4)
            {
            	break;
            }

            bytes = Socket->ReceiveBuf(&data.body , data.bytes);
            CommReceiveData(String(data.body.cLotid)  +" : "+ (data.body.cPCBid) );
            CommReceiveData(IntToStr(data.body.nIndexno )  +" : "+ IntToStr(data.body.nJobno ) );
            CommReceiveData(String(data.body.cJobname  )  +" : "+ (data.body.cMapInfo) );

//
//            if (bytes != data.bytes)
//            {
//            	break;
//            }


            EditComm1->Text = data.body.cLotid;
            EditComm2->Text = data.body.cPCBid;
            EditComm3->Text = IntToStr(data.body.nJobno);
            EditComm4->Text = data.body.cJobname;
            EditComm5->Text = data.body.cMapInfo;

            break;
        }

    }

	catch (Exception &e)
	{
		CommReceiveData( e.Message.c_str() );
	}

	delete [] buf;
}
//---------------------------------------------------------------------------

void __fastcall TFrmMain::ServerSocketClientConnect(TObject *Sender, TCustomWinSocket *Socket)

{
	m_ServerSocket =  Socket;
}
//---------------------------------------------------------------------------

